<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->post('/registrasi', 'RegistrasiController::registrasi');
$routes->post('/login', 'LoginController::login');

$routes->group('produk', function ($routes) {
    $routes->post('/', 'ProdukController::create');
    $routes->get('/', 'ProdukController::list');
    $routes->get('(:segment)', 'ProdukController::detail/$1');
    $routes->post('(:segment)/update', 'ProdukController::ubah/$1');
    $routes->delete('(:segment)', 'ProdukController::hapus/$1');
});

$routes->group('bid', function ($routes) {
    $routes->post('/', 'PostController::create');
    $routes->get('produk/(:segment)', 'PostController::list_by_produk/$1');
    $routes->post('(:segment)', 'PostController::ubah/$1'); // Menggunakan post untuk update agar sejalan dengan helper flutter
    $routes->delete('(:segment)', 'PostController::hapus/$1');
});
<?php

namespace App\Models;
use CodeIgniter\Model;

class MPost extends Model
{
    protected $table = 'posts';
    protected $primaryKey = 'id'; // Asumsi tabel Anda memiliki primary key 'id'
    protected $allowedFields = ['produk_id', 'member_id', 'bid_value'];
}
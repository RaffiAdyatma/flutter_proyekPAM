<?php

namespace App\Controllers;
use App\Models\MPost;

class PostController extends RestfulController
{
    // Tambah Bid Baru
    public function create()
    {
        $data = [
            'produk_id' => $this->request->getVar('produk_id'),
            'member_id' => $this->request->getVar('member_id'),
            'bid_value' => $this->request->getVar('bid_value')
        ];

        $model = new MPost();
        $model->insert($data);
        $post = $model->find($model->getInsertID());
        return $this->responseHasil(200, true, $post);
    }

    // Tampilkan Bid berdasarkan produk
    public function list_by_produk($produk_id)
    {
        $model = new MPost();
        $posts = $model->where('produk_id', $produk_id)->findAll();
        return $this->responseHasil(200, true, $posts);
    }

    // Ubah Bid
    public function ubah($id)
    {
        $data = [
            'bid_value' => $this->request->getVar('bid_value')
        ];

        $model = new MPost();
        $model->update($id, $data);
        $post = $model->find($id);

        return $this->responseHasil(200, true, $post);
    }

    // Hapus Bid
    public function hapus($id)
    {
        $model = new MPost();
        $post = $model->delete($id);
        return $this->responseHasil(200, true, $post);
    }
}
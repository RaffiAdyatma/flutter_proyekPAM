<?php

namespace App\Controllers;

use App\Models\MProduk;

class ProdukController extends RestfulController
{
    public function create()
    {
        $fileGambar = $this->request->getFile('gambar');
        $namaGambar = null;

        if ($fileGambar && $fileGambar->isValid() && !$fileGambar->hasMoved()) {
            $namaGambar = $fileGambar->getRandomName();
            $fileGambar->move(FCPATH . 'uploads', $namaGambar);
        }


        $data = [
            'kode_produk' => $this->request->getVar('kode_produk'),
            'nama_produk' => $this->request->getVar('nama_produk'),
            'harga' => $this->request->getVar('harga'),
            'gambar' => $namaGambar
        ];

        $model = new MProduk();
        $model->insert($data);
        $produk = $model->find($model->getInsertID());
        return $this->responseHasil(200, true, $produk);
    }

    public function list() 
    {
        $model = new MProduk();
        $produk = $model->findAll();
        return $this->responseHasil(200, true, $produk);
    }

    public function detail($id)
    {
        $model = new MProduk();
        $produk = $model->find($id);
        return $this->responseHasil(200, true, $produk);
    }

    public function ubah($id)
    {

        $model = new MProduk();
        $produkLama = $model->find($id);

        $fileGambar = $this->request->getFile('gambar');
        $namaGambar = $produkLama['gambar'] ?? null; // Tetap pakai gambar lama secara default

        if ($fileGambar && $fileGambar->isValid() && !$fileGambar->hasMoved()) {
            // Hapus gambar lama di folder jika ada gambar baru yang masuk
            if ($namaGambar && file_exists(FCPATH . 'uploads/' . $namaGambar)) {
                unlink(FCPATH . 'uploads/' . $namaGambar);
            }
            // Simpan gambar baru
            $namaGambar = $fileGambar->getRandomName();
            $fileGambar->move(FCPATH . 'uploads', $namaGambar);
        }

        $data = [
            'kode_produk' => $this->request->getVar('kode_produk'),
            'nama_produk' => $this->request->getVar('nama_produk'),
            'harga' => $this->request->getVar('harga'),
            'gambar'      => $namaGambar
        ];
        

        $model->update($id, $data);
        $produk = $model->find($id);
        return $this->responseHasil(200, true, $produk);
    }

    public function hapus($id)
    {
        $model = new MProduk();
        $produk = $model->find($id);

        if ($produk) {
            $namaGambar = $produk['gambar'];
            // Hapus file fisik gambar dari folder server
            if ($namaGambar && file_exists(FCPATH . 'uploads/' . $namaGambar)) {
                unlink(FCPATH . 'uploads/' . $namaGambar);
            }
            $model->delete($id);
        }

        return $this->responseHasil(200, true, $produk);
    }

}